package com.example.hospital.hospitalmanagement;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import java.io.File;

import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.app.Activity;
import android.content.Intent;


public class sharing extends AppCompatActivity implements View.OnClickListener {

    UserLocalStore userLocalStore;
    EditText etName, etAge, etUsername,etMedicines;;
    Button bLogout,bShare;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sharing);

        etUsername = (EditText) findViewById(R.id.etUsername);
        etMedicines =(EditText) findViewById(R.id.etMedicines);
        etName = (EditText) findViewById(R.id.etName);
        etAge = (EditText) findViewById(R.id.etAge);
        bLogout = (Button) findViewById(R.id.bLogout);
        bShare= (Button) findViewById(R.id.bShare);

        bLogout.setOnClickListener(this);
        bShare.setOnClickListener(this);

        userLocalStore = new UserLocalStore(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bLogout:
                userLocalStore.clearUserData();
                userLocalStore.setUserLoggedIn(false);
                Intent loginIntent = new Intent(this, Login.class);
                startActivity(loginIntent);
                break;
            case R.id.bShare:
                User user = userLocalStore.getLoggedInUser();
                Intent share = new Intent(android.content.Intent.ACTION_SEND);
                etUsername.setText(user.username);
                etName.setText(user.name);
                etAge.setText(user.age + "");
                etMedicines.setText(user.medi);
                String message = "";
                message += "\n User Name :\t" + etUsername.getText();
                message +="\n Patient's Address : \t" + etName.getText();
                message +="\n Patient's age :\t" +etAge.getText();
                message +="\n Patient's Medicine :\t" +etMedicines.getText();
                share.setType("text/plain");
                share.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
                share.putExtra(Intent.EXTRA_SUBJECT, "Title Of The Post");
                share.putExtra(Intent.EXTRA_TEXT,message);
                startActivity(Intent.createChooser(share, "Share link!"));
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        User user = userLocalStore.getLoggedInUser();
        etUsername.setText(user.username);
        etName.setText(user.name);
        etAge.setText(user.age + "");
        etMedicines.setText(user.medi);
    }
}
