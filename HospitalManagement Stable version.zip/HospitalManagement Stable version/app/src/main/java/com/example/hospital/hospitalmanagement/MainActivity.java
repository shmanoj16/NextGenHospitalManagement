package com.example.hospital.hospitalmanagement;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    UserLocalStore userLocalStore;
    EditText etName, etAge, etUsername,etMedicines,etPassword;
    Button bRegister,bNext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etUsername = (EditText) findViewById(R.id.etUsername);
        etName = (EditText) findViewById(R.id.etName);
        etAge = (EditText) findViewById(R.id.etAge);
        etPassword = (EditText) findViewById(R.id.etPassword);
        etMedicines =(EditText) findViewById(R.id.etMedicines);
        bRegister = (Button) findViewById(R.id.bRegister);
        bNext = (Button) findViewById(R.id.bNext);
        String password = etPassword.getText().toString();
        bRegister.setOnClickListener(this);
        bNext.setOnClickListener(this);


        userLocalStore = new UserLocalStore(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bRegister:
                String name = etName.getText().toString();
                String username = etUsername.getText().toString();
                String password = etPassword.getText().toString();
                int age = Integer.parseInt(etAge.getText().toString());
                String medi=etMedicines.getText().toString();
                Intent loginIntent = new Intent(this,Login.class);
                startActivity(loginIntent);

                User user = new User(name, age, username, password, medi);
                registerUser(user);
                break;
            case R.id.bNext:
                Intent sharingIntent = new Intent(this,sharing.class);
                startActivity(sharingIntent);


        }
    }
    private void registerUser(User user) {
        ServerRequests serverRequest = new ServerRequests(this);
        serverRequest.storeUserDataInBackground(user, new GetUserCallback() {
            @Override
            public void done(User returnedUser) {
                Intent loginIntent = new Intent(MainActivity.this, Login.class);
                startActivity(loginIntent);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (authenticate() == true) {
            displayUserDetails();
        }
    }

    private boolean authenticate() {
        if (userLocalStore.getLoggedInUser() == null) {
            Intent intent = new Intent(this, Login.class);
            startActivity(intent);
            return false;
        }
        return true;
    }

    private void displayUserDetails() {
        User user = userLocalStore.getLoggedInUser();
        etUsername.setText(user.username);
        etPassword.setText(user.password);
        etName.setText(user.name);
        etAge.setText(user.age + "");
        etMedicines.setText(user.medi);
    }
}
