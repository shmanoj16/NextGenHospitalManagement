package com.example.hospital.hospitalmanagement;


public class User {

    String name, username, password,medi;
    int age;

    public User(String name, int age, String username, String password, String medi) {
        this.name = name;
        this.age = age;
        this.username = username;
        this.password = password;
        this.medi=medi;

    }

    public User(String username, String password) {
        this("", -1, username, password,"");
    }
}
